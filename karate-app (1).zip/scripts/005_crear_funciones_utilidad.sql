-- Función para actualizar el ranking de un atleta después de un combate
CREATE OR REPLACE FUNCTION actualizar_ranking_atleta(
  p_atleta_id UUID,
  p_resultado VARCHAR, -- 'victoria', 'derrota', 'empate'
  p_puntos INTEGER
) RETURNS VOID AS $$
BEGIN
  IF p_resultado = 'victoria' THEN
    UPDATE rankings_atletas 
    SET 
      puntos_totales = puntos_totales + p_puntos,
      victorias = victorias + 1,
      updated_at = NOW()
    WHERE atleta_id = p_atleta_id;
  ELSIF p_resultado = 'derrota' THEN
    UPDATE rankings_atletas 
    SET 
      derrotas = derrotas + 1,
      updated_at = NOW()
    WHERE atleta_id = p_atleta_id;
  ELSIF p_resultado = 'empate' THEN
    UPDATE rankings_atletas 
    SET 
      puntos_totales = puntos_totales + (p_puntos / 2),
      empates = empates + 1,
      updated_at = NOW()
    WHERE atleta_id = p_atleta_id;
  END IF;
END;
$$ LANGUAGE plpgsql;

-- Función para actualizar el ranking de un equipo
CREATE OR REPLACE FUNCTION actualizar_ranking_equipo(
  p_equipo_id UUID,
  p_resultado VARCHAR,
  p_puntos INTEGER
) RETURNS VOID AS $$
BEGIN
  IF p_resultado = 'victoria' THEN
    UPDATE rankings_equipos 
    SET 
      puntos_totales = puntos_totales + p_puntos,
      victorias = victorias + 1,
      updated_at = NOW()
    WHERE equipo_id = p_equipo_id;
  ELSIF p_resultado = 'derrota' THEN
    UPDATE rankings_equipos 
    SET 
      derrotas = derrotas + 1,
      updated_at = NOW()
    WHERE equipo_id = p_equipo_id;
  ELSIF p_resultado = 'empate' THEN
    UPDATE rankings_equipos 
    SET 
      puntos_totales = puntos_totales + (p_puntos / 2),
      empates = empates + 1,
      updated_at = NOW()
    WHERE equipo_id = p_equipo_id;
  END IF;
END;
$$ LANGUAGE plpgsql;

-- Función para recalcular posiciones en el ranking de atletas
CREATE OR REPLACE FUNCTION recalcular_posiciones_atletas() RETURNS VOID AS $$
BEGIN
  WITH ranked AS (
    SELECT 
      id,
      ROW_NUMBER() OVER (PARTITION BY categoria ORDER BY puntos_totales DESC, victorias DESC) as nueva_posicion
    FROM rankings_atletas
  )
  UPDATE rankings_atletas r
  SET posicion = ranked.nueva_posicion
  FROM ranked
  WHERE r.id = ranked.id;
END;
$$ LANGUAGE plpgsql;

-- Función para recalcular posiciones en el ranking de equipos
CREATE OR REPLACE FUNCTION recalcular_posiciones_equipos() RETURNS VOID AS $$
BEGIN
  WITH ranked AS (
    SELECT 
      id,
      ROW_NUMBER() OVER (ORDER BY puntos_totales DESC, victorias DESC) as nueva_posicion
    FROM rankings_equipos
  )
  UPDATE rankings_equipos r
  SET posicion = ranked.nueva_posicion
  FROM ranked
  WHERE r.id = ranked.id;
END;
$$ LANGUAGE plpgsql;
